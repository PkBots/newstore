/**
 *
 * @param { string } prefix
 */
exports.formatgpt = (prefix) => {
    return `*KODE PAKET GPT MOBILE LEGEND*

14 Diamond : GPT 14
28 Diamond : GPT 28
42 Diamond : GPT 42
56 Diamond : GPT 56
70 Diamond : GPT 70
86 Diamond : GPT 86
100 Diamond : GPT 100
114 Diamond : GPT 114
172 Diamond : GPT 172
257 Diamond : GPT 257
285 Diamond : GPT 285
344 Diamond : GPT 344
429 Diamond : GPT 429
514 Diamond : GPT 514
600 Diamond : GPT 600
706 Diamond : GPT 706
720 Diamond : GPT 720
792 Diamond : GPT 792
878 Diamond : GPT 878
963 Diamond : GPT 963
1050 Diamond : GPT 1050
1220 Diamond : GPT 1220
1412 Diamond : GPT 1412
2195 Diamond : GPT 2195
2901 Diamond : GPT 2901
3688 Diamond : GPT 3688
5532 Diamond : GPT 5532
9288 Diamond : GPT 9288

Starlight Member : GPT SM
Twilight Pas : GPT TP
Starlight Plus : GPT SP

*Cara Order*
GPT 86 181619598 2951`
}

