/**
 *
 * @param { string } prefix
 */
exports.menuowner = (prefix) => {
    return `┌──⭓ *Menu Grup*
│⭔ owner
│⭔ grup (Open/Close)
│⭔ hidetag
│⭔ kick
│⭔ Done/Proses (d/p)
└───────⭓

┌──⭓ *Set Menu Harga*
│⭔ Menu
│⭔ addlist
│⭔ dellist 
│⭔ updatelist 
└───────⭓`
}

