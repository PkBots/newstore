/**
 *
 * @param { string } prefix
 */
exports.formatmlc = (prefix) => {
    return `*KODE PAKET C MOBILE LEGEND*

14     Diamond  : MLC 14
28     Diamond  : MLC 28
42     Diamond  : MLC 42
56     Diamond  : MLC 56
70     Diamond  : MLC 70
112   Diamond  : MLC 112
140   Diamond  : MLC 140
284   Diamond  : MLC 284
355   Diamond  : MLC 355
429   Diamond  : MLC 429
716   Diamond  : MLC 716
1446 Diamond  : MLC 1446

Starlight Member : MLC SL
Twilight Pas : MLC TP
Starlight Plus : MLC SLP

*Cara Order*
MLC 86 181619598 2951`
}

