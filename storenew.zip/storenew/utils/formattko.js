/**
 *
 * @param { string } prefix
 */
exports.formattko = (prefix) => {
    return `*KODE TOKOVOUCHER TRANSAKSI*
LIHAT DI https://member.tokovoucher.id/produk

Contoh Format FF Murah
TKO PFF720 72636372727

Contoh Format ML Smile
TKOS MLA86 727373838 7272

*Baca- Penting*
*Format TKOS hanya untuk Mobile Legends/ ID + Server*`
}

