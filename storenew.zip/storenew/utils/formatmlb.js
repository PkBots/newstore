/**
 *
 * @param { string } prefix
 */
exports.formatmlb = (prefix) => {
    return `*KODE PAKET B MOBILE LEGEND*

86     Diamond : MLB 86
172   Diamond : MLB 172
257   Diamond : MLB 257
706   Diamond : MLB 706
2195 Diamond : MLB 2195
3688 Diamond : MLB 3688
5532 Diamond : MLB 5532
9288 Diamond : MLB 9288

Starlight Member : PMLB SL12
Twilight Pas : MLB TP
Starlight Plus : MLB SLP

*Cara Order*
MLB 86 181619598 2951`
}

