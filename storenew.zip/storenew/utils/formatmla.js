/**
 *
 * @param { string } prefix
 */
exports.formatmla = (prefix) => {
    return `*KODE PAKET A MOBILE LEGEND*

86     Diamond : MLA 86
172   Diamond : MLA 172
257   Diamond : MLA 257
344   Diamond : MLA 344
429   Diamond : MLA 429
514   Diamond : MLA 514
600   Diamond : MLA 600
706   Diamond : MLA 706
792   Diamond : MLA 792
878   Diamond : MLA 878
963   Diamond : MLA 963
1050 Diamond : MLA 1050
1220 Diamond : MLA 1220
1412 Diamond : MLA 1412
2195 Diamond : MLA 2195
2901 Diamond : MLA 2901
3073 Diamond : MLA 3073
3688 Diamond : MLA 3688
4394 Diamond : MLA 4394
5532 Diamond : MLA 5532
6238 Diamond : MLA 6238
7727 Diamond : MLA 7727
9288 Diamond : MLA 9288

Starlight Member : MLA SM
Twilight Pas : MLA TP
Starlight Plus : MLA SP

*Cara Order*
MLA 86 1861669598 2951`
}

