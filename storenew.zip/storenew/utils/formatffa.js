/**
 *
 * @param { string } prefix
 */
exports.formatffa = (prefix) => {
    return `*KODE PAKET FREE FIRE*

5       Diamond : FFA 5
10     Diamond : FFA 10
15     Diamond : FFA 15
20     Diamond : FFA 20
25     Diamond : FFA 25
30     Diamond : FFA 30
40     Diamond : FFA 40
50     Diamond : FFA 50
55     Diamond : FFA 55
60     Diamond : FFA 60
70     Diamond : FFA 70
75     Diamond : FFA 75
80     Diamond : FFA 80
90     Diamond : FFA 90
95     Diamond : FFA 95
100   Diamond : FFA 100
120   Diamond : FFA 120
130   Diamond : FFA 130
140   Diamond : FFA 140
145   Diamond : FFA 145
150   Diamond : FFA 150
160   Diamond : FFA 160
180   Diamond : FFA 180
190   Diamond : FFA 190
200   Diamond : FFA 200
210   Diamond : FFA 210
250   Diamond : FFA 250
280   Diamond : FFA 280
300   Diamond : FFA 300
350   Diamond : FFA 350
355   Diamond : FFA 355
375   Diamond : FFA 375
400   Diamond : FFA 400
405   Diamond : FFA 405
425   Diamond : FFA 425
475   Diamond : FFA 475
500   Diamond : FFA 500
510   Diamond : FFA 510
515   Diamond : FFA 515
545   Diamond : FFA 545
565   Diamond : FFA 565
600   Diamond : FFA 600
635   Diamond : FFA 635
645   Diamond : FFA 645
655   Diamond : FFA 655
700   Diamond : FFA 700
720   Diamond : FFA 720
770   Diamond : FFA 770
790   Diamond : FFA 790
800   Diamond : FFA 800
860   Diamond : FFA 860
930   Diamond : FFA 930
1000 Diamond : FFA 1000
1050 Diamond : FFA 1050
1075 Diamond : FFA 1075
1080 Diamond : FFA 1080
1200 Diamond : FFA 1200
1215 Diamond : FFA 1215
1300 Diamond : FFA 1300
1440 Diamond : FFA 1440
1450 Diamond : FFA 1450
1490 Diamond : FFA 1490
1510 Diamond : FFA 1510
1580 Diamond : FFA 1580
1795 Diamond : FFA 1795
1800 Diamond : FFA 1800
2000 Diamond : FFA 2000
2140 Diamond : FFA 2140
2190 Diamond : FFA 2190
2210 Diamond : FFA 2210
2280 Diamond : FFA 2280
2355 Diamond : FFA 2355
2720 Diamond : FFA 2720
4000 Diamond : FFA 4000
7290 Diamond : FFA 7290

M. MINGGUAN : FFA M
M. BULANAN : FFA B
Level Up pass : FFA LUP

*Cara Order*
contoh : FFA 140 181619598`
}

